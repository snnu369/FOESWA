%CFLS
clear all
clc
h=0.005;%step length
t=0;% initial time
ee=8000;%times
x11=0.2;x21=0.2;x12=0.2;x22=0.2;%initial condition
x11jian=0.05;x12jian=0.05;x21jian=0.05;x22jian=0.05;%(10)initial condition
eta11=0.05;eta12=0.05;eta21=0.05;eta22=0.05;% (14)initial condition
pi11jian=0;pi21jian=0;pi12jian=0;pi22jian=0;% (22) \hat{\pi}initial condition
chi11=0.01;chi12=0.01;chi21=0.01;chi22=0.01;%(19)initial condition
mu1=1.5;mu2=1.5;
L11=4;L12=4;L21=4;L22=6;%
m11=12;m12=25;m21=12;m22=18;%��10��
rt1=0;rtt1=0;tk1=0;num1=0;rt2=0;rtt2=0;tk2=0;num2=0;%event-triggered policy 
kappa=2;
k11=20;k12=30;k21=15;k22=25;%��24����33����42��
gamma11=1;gamma12=1;gamma21=1;gamma22=1;eta01=1;%��22��
as11=0.25;as12=0.25;as21=0.25;as22=0.25;
pro11=0.25;pro12=0.25;pro21=0.25;pro22=0.25;
bpro11=0.05;bpro21=0.05;bpro12=0.05;bpro22=0.05;
kb11=0.4;kb12=0.4;kb21=0.4;kb22=0.4;
kbc11=1.5*ones(1,ee);kbc12=1.5*ones(1,ee);kbcc1=0.4*ones(1,ee);
kbc111=-kbc11;kbc121=-kbc12;kbcc11=-kbcc1;
kbc21=1.5*ones(1,ee);kbc22=1.5*ones(1,ee);kbcc2=0.4*ones(1,ee);
kbc211=-kbc21;kbc221=-kbc22;kbcc22=-kbcc2;
tao12=0.02;tao22=0.02;
a11=1;a21=1;
w11=-0.1*ones(16,1);w12=0.02*ones(64,1);w21=-0.1*ones(16,1);w22=0.2*ones(256,1);
q11=5;q12=5;q21=5;q22=5;
alpha=0.96;
for n=1:ee
    t(n+1)=t(n)+h;
    y1d(n)=0.6*sin(0.5*t(n))+0.5*sin(0.2*t(n));
    y2d(n)=0.5*sin(0.1*t(n))+0.6*sin(0.5*t(n));
    dddy1d(n)=0.3*cos(0.5*t(n))+0.1*cos(0.2*t(n));
    dddy2d(n)=0.05*cos(t(n))+0.3*cos(0.5*t(n));
    kaka1=(t(n+1)-t(1:n)).^(-alpha);% 
    kaka2=(t(n+1)-t(1:n)).^(alpha-1); %  
    ddy1d=kaka1.*dddy1d/gamma(1-alpha);
    ddy2d=kaka1.*dddy2d/gamma(1-alpha);
    dy1d(n)=sum(ddy1d)*h;
    dy2d(n)=sum(ddy2d)*h;
    f11(n)=0.1*x11(n)*sin(x12(n));
    f12(n)=x11(n)*(sin(x21(n)*x12(n)));
    f21(n)=0.5*x22(n)+x21(n);
    f22(n)=x22(n)+x21(n)-0.5*x11(n)*x12(n);
    d11(n)=0.01*sin(t(n));
    d12(n)=0.01*cos(t(n));
    d21(n)=0.01*sin(t(n));
    d22(n)=0.01*cos(t(n));
    
    lamda11(1)=0.001;
    z11(n)=x11(n)-y1d(n)-lamda11(n);
    v11(n)=z11(n)-chi11(n);
    kk11=1;   
    for ii11=-1.5:1:1.5
        for ii111=-1.5:1:1.5
        p11(kk11)=gaussmf(x11(n),[0.2,ii11])*gaussmf(x12(n),[0.2,ii111]); 
        kk11=kk11+1;
        end
    end
    ps11(:,n)=p11'/sum(p11);      %fuzzy logic system     
    sigma11(n)=x11jian(n)-eta11(n);
    www11(:,n)=gamma11*((v11(n)/((kb11)^2-(v11(n))^2))+sigma11(n)/as11)*ps11(:,n)-pro11*w11(:,n);
    ww11=kaka2.*www11/gamma(alpha);
    w11(:,n+1)=w11(:,1)+h*sum(ww11,2);
    pi11jian11(n)=((eta01*v11(n))/((kb11)^2-(v11(n))^2))*tanh(v11(n)/(kappa*((kb11)^2-(v11(n))^2)))-bpro11*pi11jian(n);
    pi11jian1=kaka2.*pi11jian11/gamma(alpha);
    pi11jian(n+1)=pi11jian(1)+h*sum(pi11jian1);

    beta11(n)=-k11*z11(n)-w11(:,n)'*ps11(:,n)+dy1d(n)-q11*lamda11(n)-(a11*(mu1^2)*v11(n))/(2*((kb11)^2-(v11(n))^2))-pi11jian(n)*tanh(v11(n)/(kappa*((kb11)^2-(v11(n))^2)));
    alpha12(1)=beta11(1);
    alpha1211(n)=(beta11(n)-alpha12(n))/tao12;
    alpha121=kaka2.* alpha1211/gamma(alpha);
    alpha12(n+1)=alpha12(1)+h*sum(alpha121);
    
    chi1111(n)=-k11*chi11(n)+chi12(n)+(alpha12(n)-beta11(n));
    chi111=kaka2.*chi1111/gamma(alpha);
    chi11(n+1)=chi11(1)+h*sum(chi111);
    x11jian11(n)=x12jian(n)+m11*(y1d(n)-x11jian(n))+w11(:,n)'*ps11(:,n);
    x11jian1=kaka2.*x11jian11/gamma(alpha);
    x11jian(n+1)=x11jian(1)+h*sum(x11jian1);
    eta1111(n)=x12jian(n)+L11*(x11jian(n)-eta11(n))+w11(:,n)'*ps11(:,n);
    eta111=kaka2.*eta1111/gamma(alpha);
    eta11(n+1)=eta11(1)+h*sum(eta111);
    
    lamda12(1)=0.001;
    z12(n)=x12jian(n)-alpha12(n)-lamda12(n);
    v12(n)=z12(n)-chi12(n);
     kk12=1;   
    for ii12=-1.5:1:1.5
        for ii112=-1.5:1:1.5
            for ii1112=-1.5:1:1.5
                 p12(kk12)=gaussmf(x11(n),[0.2,ii12])*gaussmf(x12(n),[0.5,ii112])*gaussmf(x21(n),[0.2,ii1112]);
                kk12=kk12+1;
            end
        end
    end
    ps12(:,n)=p12'/sum(p12);   
    
    sigma12(n)=x12jian(n)-eta12(n);
    www12(:,n)=gamma12*((v12(n)/((kb12)^2-(v12(n))^2))+sigma12(n)/as12)*ps12(:,n)-pro12*w12(:,n);
    ww12=kaka2.*www12/gamma(alpha);
    w12(:,n+1)=w12(:,1)+h*sum(ww12,2);
    pi12jian11(n)=((eta01*v12(n))/((kb12)^2-(v12(n))^2))*tanh(v12(n)/(kappa*((kb12)^2-(v12(n))^2)))-bpro12*pi12jian(n);
    pi12jian1=kaka2.*pi12jian11/gamma(alpha);
    pi12jian(n+1)=pi12jian(1)+h*sum(pi12jian1);
    phi1(n)=-k12*z12(n)-w12(:,n)'*ps12(:,n)+alpha1211(n)-m12*(y1d(n)-x11jian(n))-q12*lamda12(n)-(((kb12)^2-(v12(n))^2)*z11(n))/((kb11)^2-(v11(n))^2)-pi12jian(n)*tanh(v12(n)/(kappa*((kb12)^2-(v12(n))^2)));
   theta1=0.2;iota1=0.2;bariota1=0.1;
   iotalq=0.25;bariota1q=0.2;varsigmal1=1;
    eta1(n)=-(1+theta1)*(phi1(n)*tanh((v12(n)*phi1(n))/(varsigmal1*((kb12)^2-(v12(n))^2)))+iota1*tanh((v12(n)*iota1)/(varsigmal1*((kb12)^2-(v12(n))^2))));
    eta1q(n)=phi1(n)-iotalq*tanh((v12(n)*iotalq)/(varsigmal1*((kb12)^2-(v12(n))^2)));
    count1=(n-1)*h;% 
    if abs(phi1(n))<0.5
    if n>1 &&  abs(phi1(n)-vv1(n-1))<(bariota1+theta1*abs(vv1(n-1)))
       vv1(n)=vv1(n-1);
    else 
        vv1(n)=phi1(n);
        rt1=[rt1;count1];% 
        rtt1=[rtt1;count1-tk1];% 
        tk1=count1;% 
        num1=num1+1;
    end
    else 
       if n>1 &&  abs(phi1(n)-vv1(n-1))<bariota1q
       vv1(n)=vv1(n-1);
    else 
        vv1(n)=phi1(n);
        rt1=[rt1;count1];% 
        rtt1=[rtt1;count1-tk1];% 
        tk1=count1;% 
        num1=num1+1;
    end 
    end   
      
  u1min=20;u1max=10;
   if vv1(n)>=u1max
      u1(n)=u1max;
    elseif -u1min<vv1(n) && vv1(n)<u1max
       u1(n)=vv1(n);
   else 
       u1(n)=-u1min;
   end
  
   du1(n)=u1(n)-vv1(n);
   lam122(n)=-q12*lamda12(n)+du1(n);
   lam12=kaka2.*lam122/gamma(alpha);
   lamda12(n+1)=lamda12(1)+h*sum(lam12);
   lam111(n)=lamda12(n)-q11*lamda11(n);
   lam11=kaka2.*lam111/gamma(alpha);
   lamda11(n+1)=lamda11(1)+h*sum(lam11);
   chi1211(n)=-k12*chi12(n)-(((kb12)^2-(v12(n))^2)/(kb11^2-(v11(n))^2))*chi11(n);
   chi121=kaka2.*chi1211/gamma(alpha);
   chi12(n+1)=chi12(1)+h*sum(chi121);
    x12jian11(n)=u1(n)+m12*(y1d(n)-x11jian(n))+w12(:,n)'*ps12(:,n);
    x12jian1=kaka2.*x12jian11/gamma(alpha);
    x12jian(n+1)=x12jian(1)+h*sum(x12jian1);
    eta1211(n)=u1(n)+L12*(x12jian(n)-eta12(n))+w12(:,n)'*ps12(:,n);
    eta121=kaka2.*eta1211/gamma(alpha);
    eta12(n+1)=eta12(1)+h*sum(eta121);
    
   
   xxx11(n)=x12(n)+f11(n)+d11(n);
   xx11=kaka2.*xxx11/gamma(alpha);
   x11(n+1)=x11(1)+h*sum(xx11);
   xxx12(n)=u1(n)+f12(n)+d12(n);
   xx12=kaka2.*xxx12/gamma(alpha);
   x12(n+1)=x12(1)+h*sum(xx12);
  
  lamda21(1)=0.01;
  z21(n)=x21(n)-y2d(n)-lamda21(n);
  v21(n)=z21(n)-chi21(n);
  kk21=1;   
    for ii21=-1.5:1:1.5
        for ii211=-1.5:1:1.5
        p21(kk21)=gaussmf(x21(n),[0.2,ii21])*gaussmf(x22(n),[0.2,ii211]); 
        kk21=kk21+1;
        end
    end
    ps21(:,n)=p21'/sum(p21);
    sigma21(n)=x21jian(n)-eta21(n);
    www21(:,n)=gamma21*((v21(n)/((kb21)^2-(v21(n))^2))+sigma21(n)/as21)*ps21(:,n)-pro21*w21(:,n);
    ww21=kaka2.*www21/gamma(alpha);
    w21(:,n+1)=w21(:,1)+h*sum(ww21,2);
    pi21jian11(n)=((eta01*v21(n))/((kb21)^2-(v21(n))^2))*tanh(v21(n)/(kappa*((kb21)^2-(v21(n))^2)))-bpro21*pi21jian(n);
    pi21jian1=kaka2.*pi21jian11/gamma(alpha);
    pi21jian(n+1)=pi21jian(1)+h*sum(pi21jian1);
    beta21(n)=-k21*z21(n)-w21(:,n)'*ps21(:,n)+dy2d(n)-q21*lamda21(n)-(a21*(mu2^2)*v21(n))/(2*((kb21)^2-(v21(n))^2))-pi21jian(n)*tanh(v21(n)/(kappa*((kb21)^2-(v21(n))^2)));
    
    alpha22(1)=beta21(1);
    alpha2211(n)=(beta21(n)-alpha22(n))/tao12;
    alpha221=kaka2.* alpha2211/gamma(alpha);
    alpha22(n+1)=alpha22(1)+h*sum(alpha221);
    chi2111(n)=-k21*chi21(n)+chi22(n)+(alpha22(n)-beta21(n));
    chi211=kaka2.*chi2111/gamma(alpha);
    chi21(n+1)=chi21(1)+h*sum(chi211);
    x21jian11(n)=x22jian(n)+m21*(y2d(n)-x21jian(n))+w21(:,n)'*ps21(:,n);
    x21jian1=kaka2.*x21jian11/gamma(alpha);
    x21jian(n+1)=x21jian(1)+h*sum(x21jian1);
    eta2111(n)=x22jian(n)+L21*(x21jian(n)-eta21(n))+w21(:,n)'*ps21(:,n);
    eta211=kaka2.*eta2111/gamma(alpha);
    eta21(n+1)=eta21(1)+h*sum(eta211);
    
    lamda22(1)=0.001;
    
    z22(n)=x22jian(n)-alpha22(n)-lamda22(n);
    v22(n)=z22(n)-chi22(n);
     kk22=1;   
    for ii22=-1.5:1:1.5
        for ii222=-1.5:1:1.5
            for ii2222=-1.5:1:1.5
                for ii22222=-1.5:1:1.5
                 p22(kk22)=gaussmf(x11(n),[0.2,ii22])*gaussmf(x12(n),[0.5,ii222])*gaussmf(x21(n),[0.2,ii2222])*gaussmf(x22(n),[0.2,ii22222]);
                kk22=kk22+1;
                end
            end
        end
    end
    ps22(:,n)=p22'/sum(p22);   
    sigma22(n)=x22jian(n)-eta22(n);
    www22(:,n)=gamma22*((v22(n)/((kb22)^2-(v22(n))^2))+sigma22(n)/as22)*ps22(:,n)-pro22*w22(:,n);
    ww22=kaka2.*www22/gamma(alpha);
    w22(:,n+1)=w22(:,1)+h*sum(ww22,2);
    pi22jian11(n)=((eta01*v22(n))/((kb22)^2-(v22(n))^2))*tanh(v22(n)/(kappa*((kb22)^2-(v21(n))^2)))-bpro22*pi22jian(n);
    pi22jian1=kaka2.*pi22jian11/gamma(alpha);
    pi22jian(n+1)=pi22jian(1)+h*sum(pi22jian1);
  
    phi2(n)=-k22*z22(n)-w22(:,n)'*ps22(:,n)+alpha2211(n)-m22*(y2d(n)-x21jian(n))-q22*lamda22(n)-(((kb22)^2-(v22(n))^2)*z21(n))/((kb21)^2-(v21(n))^2)-pi22jian(n)*tanh(v22(n)/(kappa*((kb22)^2-(v22(n))^2)));
    theta2=0.2;iota2=0.2;bariota2=0.1;
    iota2q=0.25;bariota2q=0.2;varsigmal2=1;
   eta2(n)=-(1+theta2)*(phi2(n)*tanh((v22(n)*phi2(n))/(varsigmal2*(kb22^2-(v22(n))^2)))+iota2*tanh((v22(n)*iota2)/(varsigmal2*(kb22^2-(v22(n))^2))));
     eta2q(n)=phi2(n)-iota2q*tanh((v22(n)*iota2q)/(varsigmal2*(kb22^2-(v22(n))^2)));
    count2=(n-1)*h;% 
    if abs(phi2(n))<0.5
    if n>1 &&  abs(phi2(n)-vv2(n-1))<(bariota2+theta2*abs(vv2(n-1)))
       vv2(n)=vv2(n-1);
    else 
        vv2(n)=phi2(n);
        rt2=[rt2;count2];% 
        rtt2=[rtt2;count2-tk2];% 
        tk2=count2;% 
        num2=num2+1;
    end
    else
         if n>1 &&  abs(phi2(n)-vv2(n-1))<bariota2q
       vv2(n)=vv2(n-1);
    else 
        vv2(n)=phi2(n);
        rt2=[rt2;count2];% 
        rtt2=[rtt2;count2-tk2];% 
        tk2=count2;% 
        num2=num2+1;
    end
    end
  u2min=25;u2max=10;
   if vv2(n)>=u2max
      u2(n)=u2max;
    elseif -u2min<vv2(n)&&vv2(n)<u2max
       u2(n)=vv2(n);
   else 
       u2(n)=-u2min;
   end
   
   du2(n)=u2(n)-vv2(n);
   lam222(n)=-q22*lamda22(n)+du2(n);
   lam22=kaka2.*lam222/gamma(alpha);
   lamda22(n+1)=lamda22(1)+h*sum(lam22);
   lam211(n)=lamda22(n)-q21*lamda21(n);
   lam21=kaka2.*lam211/gamma(alpha);
   lamda21(n+1)=lamda21(1)+h*sum(lam21);
    chi2211(n)=-k22*chi22(n)-((kb22^2-(v22(n))^2)/(kb21^2-(v21(n))^2))*chi21(n);
   chi221=kaka2.*chi2211/gamma(alpha);
   chi22(n+1)=chi22(1)+h*sum(chi221);
    x22jian11(n)=u2(n)+m22*(y2d(n)-x21jian(n))+w22(:,n)'*ps22(:,n);
    x22jian1=kaka2.*x22jian11/gamma(alpha);
    x22jian(n+1)=x22jian(1)+h*sum(x22jian1);
    eta2211(n)=u2(n)+L22*(x22jian(n)-eta22(n))+w22(:,n)'*ps22(:,n);
    eta221=kaka2.*eta2211/gamma(alpha);
    eta22(n+1)=eta22(1)+h*sum(eta221);
    
    
   xxx21(n)=x22(n)+f21(n)+d21(n);
   xx21=kaka2.*xxx21/gamma(alpha);
   x21(n+1)=x21(1)+h*sum(xx21);
   xxx22(n)=u2(n)+f22(n)+d22(n);
   xx22=kaka2.*xxx22/gamma(alpha);
   x22(n+1)=x22(1)+h*sum(xx22);
   
end 
figure(1)
subplot(2,1,1)
plot(t(1:n),y1d,'-',t,x11,'LineWidth',1.7)%t(1:n),kbcc1,t(1:n),kbcc11,
xlabel('Time(second)')
legend({'$y_{1,r}$', '$\xi_{1,1}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -1.6 2])
hold on
subplot(2,1,2)
plot(t(1:n),z11,'LineWidth',1.7)%t(1:n),kbcc1,t(1:n),kbcc11,
xlabel('Time(second)')
legend({'$z_{11}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -0.1 0.3])
hold on


figure(2)
subplot(2,1,1)
plot(t(1:n),y2d,'-',t,x21,'LineWidth',1.7)%t(1:n),kbcc1,t(1:n),kbcc11,
xlabel('Time(second)')
legend({'$y_{2,r}$', '$\xi_{2,1}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -1.6 2])
hold on
subplot(2,1,2)
plot(t(1:n),z21,'LineWidth',1.7)%t(1:n),kbcc1,t(1:n),kbcc11,
xlabel('Time(second)')
legend({'$z_{21}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -0.1 0.3])
hold on

figure(3)
subplot(2,1,1)
plot(t(1:n),x11(1:n),t(1:n),x11jian(1:n),'--','LineWidth',2)
xlabel('Time(second)')
legend({'$\xi_{1,1}$', '$\hat{\xi}_{1,1}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -2 2.5])
hold on
subplot(2,1,2)
plot(t(1:n),x12(1:n),t(1:n),x12jian(1:n),'--','LineWidth',2)
xlabel('Time(second)')
legend({'$\xi_{1,2}$', '$\hat{\xi}_{1,2}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -2 2.5])
hold on

figure(4)
subplot(2,1,1)
plot(t(1:n),x21(1:n),t(1:n),x21jian(1:n),'--','LineWidth',2)
xlabel('Time(second)')
legend({'$\xi_{2,1}$', '$\hat{\xi}_{2,1}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -2 2.5])
hold on
subplot(2,1,2)
plot(t(1:n),x22(1:n),t(1:n),x22jian(1:n),'--','LineWidth',2)
xlabel('Time(second)')
legend({'$\xi_{2,2}$', '$\hat{\xi}_{2,2}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -2 2.5])
hold on 
% 
figure(5)
subplot(2,1,1)
plot(t(1:n),u1,t(1:n),phi1,'--','LineWidth',2)
xlabel('Time(second)')
legend({'$u_{1}(\bar{v}_{1})$','$\phi_1$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -30 20])
subplot(2,1,2)
stem(rt1,rtt1,'LineWidth',1.7)
xlabel('Time(second)')
ylabel('Amplitude') 



figure(6)
subplot(2,1,1)
plot(t(1:n),u2,t(1:n),phi2,'--','LineWidth',2)
xlabel('Time(second)')
legend({'$u_{2}(\bar{v}_{2})$','$\phi_2$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -30 20])
subplot(2,1,2)
stem(rt2,rtt2,'LineWidth',1.7)
xlabel('Time(second)')
ylabel('Amplitude') 




%FLS
clear all
clc
h=0.005;%step length
t=0;% initial time
x11=0.2;x21=0.2;x12=0.2;x22=0.2;%system (7)initial condition
x11jian=0.05;x12jian=0.05;x21jian=0.05;x22jian=0.05;%observer (10)initial condition
mu1=1.5;mu2=1.5;%\mu
rt1=0;rtt1=0;tk1=0;num1=0;rt2=0;rtt2=0;tk2=0;num2=0;%event-triggered policy 
chi11=0.01;chi12=0.01;chi21=0.01;chi22=0.01;%auxiliary system(19)initial condition
kappa=2;
m11=12;m12=20;m21=12;m22=18;%��10��
k11=20;k12=30;k21=15;k22=25;%��24����33����42��
gamma11=1;gamma12=1;gamma21=1;gamma22=1;%��22��
eta01=1;
pro11=0.25;pro12=0.25;pro21=0.25;pro22=0.25;
bpro11=0.05;bpro21=0.05;bpro12=0.05;bpro22=0.05;
ee=8000;
kb11=0.4;kb12=0.4;kb21=0.4;kb22=0.4;%
kbc11=1.5*ones(1,ee);kbc12=1.5*ones(1,ee);kbcc1=0.4*ones(1,ee);
kbc111=-kbc11;kbc121=-kbc12;kbcc11=-kbcc1;
kbc21=1.5*ones(1,ee);kbc22=1.5*ones(1,ee);kbcc2=0.4*ones(1,ee);
kbc211=-kbc21;kbc221=-kbc22;kbcc22=-kbcc2;
tao12=0.02;tao22=0.02;%
a11=1;a21=1;%
w11=-0.1*ones(16,1);w12=0.02*ones(64,1);w21=-0.1*ones(16,1);w22=0.2*ones(256,1);
q11=5;q12=5;q21=5;q22=5;
alpha=0.96;
for n=1:ee
    t(n+1)=t(n)+h;
    y1d(n)=0.6*sin(0.5*t(n))+0.5*sin(0.2*t(n));
    y2d(n)=0.5*sin(0.1*t(n))+0.6*sin(0.5*t(n));
    dddy1d(n)=0.3*cos(0.5*t(n))+0.1*cos(0.2*t(n));
    dddy2d(n)=0.05*cos(t(n))+0.3*cos(0.5*t(n));
    kaka1=(t(n+1)-t(1:n)).^(-alpha);%
    kaka2=(t(n+1)-t(1:n)).^(alpha-1); % 
    ddy1d=kaka1.*dddy1d/gamma(1-alpha);
    ddy2d=kaka1.*dddy2d/gamma(1-alpha);
    dy1d(n)=sum(ddy1d)*h;
    dy2d(n)=sum(ddy2d)*h;
    f11(n)=0.1*x11(n)*sin(x12(n));
    f12(n)=1*x11(n)*(sin(x21(n)*x12(n)));
    f21(n)=0.5*x22(n)+x21(n);
    f22(n)=x22(n)+x21(n)-0.5*x11(n)*x12(n);
    d11(n)=0.01*sin(t(n));
    d12(n)=0.01*cos(t(n));
    d21(n)=0.01*sin(t(n));
    d22(n)=0.01*cos(t(n));
    
    lamda11(1)=0.001;
    z11(n)=x11(n)-y1d(n)-lamda11(n);
    v11(n)=z11(n)-chi11(n);
    kk11=1;   
    for ii11=-1.5:1:1.5
        for ii111=-1.5:1:1.5
        p11(kk11)=gaussmf(x11(n),[0.2,ii11])*gaussmf(x12(n),[0.2,ii111]); 
        kk11=kk11+1;
        end
    end
    ps11(:,n)=p11'/sum(p11);      %fuzzy logic system     
   
    www11(:,n)=gamma11*((v11(n)/((kb11)^2-(v11(n))^2)))*ps11(:,n)-pro11*w11(:,n);
    ww11=kaka2.*www11/gamma(alpha);
    w11(:,n+1)=w11(:,1)+h*sum(ww11,2);
    

    beta11(n)=-k11*z11(n)-w11(:,n)'*ps11(:,n)+dy1d(n)-q11*lamda11(n);
    alpha12(1)=beta11(1);
    alpha1211(n)=(beta11(n)-alpha12(n))/tao12;
    alpha121=kaka2.* alpha1211/gamma(alpha);
    alpha12(n+1)=alpha12(1)+h*sum(alpha121);
    
    chi1111(n)=-k11*chi11(n)+chi12(n)+(alpha12(n)-beta11(n));
    chi111=kaka2.*chi1111/gamma(alpha);
    chi11(n+1)=chi11(1)+h*sum(chi111);
    
    x11jian11(n)=x12jian(n)+m11*(y1d(n)-x11jian(n))+w11(:,n)'*ps11(:,n);
    x11jian1=kaka2.*x11jian11/gamma(alpha);
    x11jian(n+1)=x11jian(1)+h*sum(x11jian1);
    
    
    lamda12(1)=0.001;
    z12(n)=x12jian(n)-alpha12(n)-lamda12(n);
    v12(n)=z12(n)-chi12(n);
     kk12=1;   
    for ii12=-1.5:1:1.5
        for ii112=-1.5:1:1.5
            for ii1112=-1.5:1:1.5
                 p12(kk12)=gaussmf(x11(n),[0.2,ii12])*gaussmf(x12(n),[0.5,ii112])*gaussmf(x21(n),[0.2,ii1112]);
                kk12=kk12+1;
            end
        end
    end
    ps12(:,n)=p12'/sum(p12);   
    
   
    www12(:,n)=gamma12*((v12(n)/((kb12)^2-(v12(n))^2)))*ps12(:,n)-pro12*w12(:,n);
    ww12=kaka2.*www12/gamma(alpha);
    w12(:,n+1)=w12(:,1)+h*sum(ww12,2);
    
    phi1(n)=-k12*z12(n)-w12(:,n)'*ps12(:,n)+alpha1211(n)-m12*(y1d(n)-x11jian(n))-q12*lamda12(n)-(((kb12)^2-(v12(n))^2)*z11(n))/((kb11)^2-(v11(n))^2);
   theta1=0.2;iota1=0.2;bariota1=0.1;
   iotalq=0.25;bariota1q=0.2;varsigmal1=1;
    eta1(n)=-(1+theta1)*(phi1(n)*tanh((v12(n)*phi1(n))/(varsigmal1*((kb12)^2-(v12(n))^2)))+iota1*tanh((v12(n)*iota1)/(varsigmal1*((kb12)^2-(v12(n))^2))));
    eta1q(n)=phi1(n)-iotalq*tanh((v12(n)*iotalq)/(varsigmal1*((kb12)^2-(v12(n))^2)));
    count1=(n-1)*h;% 
    if abs(phi1(n))<0.5
    if n>1 &&  abs(phi1(n)-vv1(n-1))<(bariota1+theta1*abs(vv1(n-1)))
       vv1(n)=vv1(n-1);
    else 
        vv1(n)=phi1(n);
        rt1=[rt1;count1];% 
        rtt1=[rtt1;count1-tk1];% 
        tk1=count1;% 
        num1=num1+1;
    end
    else 
       if n>1 &&  abs(phi1(n)-vv1(n-1))<bariota1q
       vv1(n)=vv1(n-1);
    else 
        vv1(n)=phi1(n);
        rt1=[rt1;count1];% 
        rtt1=[rtt1;count1-tk1];%  
        tk1=count1;% 
        num1=num1+1;
    end 
    end   
      
  u1min=20;u1max=10;
   if vv1(n)>=u1max
      u1(n)=u1max;
    elseif -u1min<vv1(n) && vv1(n)<u1max
       u1(n)=vv1(n);
   else 
       u1(n)=-u1min;
   end
  
   du1(n)=u1(n)-vv1(n);
   lam122(n)=-q12*lamda12(n)+du1(n);
   lam12=kaka2.*lam122/gamma(alpha);
   lamda12(n+1)=lamda12(1)+h*sum(lam12);
   lam111(n)=lamda12(n)-q11*lamda11(n);
   lam11=kaka2.*lam111/gamma(alpha);
   lamda11(n+1)=lamda11(1)+h*sum(lam11);
   chi1211(n)=-k12*chi12(n)-(((kb12)^2-(v12(n))^2)/(kb11^2-(v11(n))^2))*chi11(n);
   chi121=kaka2.*chi1211/gamma(alpha);
   chi12(n+1)=chi12(1)+h*sum(chi121);
    x12jian11(n)=u1(n)+m12*(y1d(n)-x11jian(n))+w12(:,n)'*ps12(:,n);
    x12jian1=kaka2.*x12jian11/gamma(alpha);
    x12jian(n+1)=x12jian(1)+h*sum(x12jian1);
    
    f12jian(n)=w12(:,n)'*ps12(:,n);
 
   xxx11(n)=x12(n)+f11(n)+d11(n);
   xx11=kaka2.*xxx11/gamma(alpha);
   x11(n+1)=x11(1)+h*sum(xx11);
   xxx12(n)=u1(n)+f12(n)+d12(n);
   xx12=kaka2.*xxx12/gamma(alpha);
   x12(n+1)=x12(1)+h*sum(xx12);
  
  lamda21(1)=0.01;
  z21(n)=x21(n)-y2d(n)-lamda21(n);
  v21(n)=z21(n)-chi21(n);
  kk21=1;   
    for ii21=-1.5:1:1.5
        for ii211=-1.5:1:1.5
        p21(kk21)=gaussmf(x21(n),[0.2,ii21])*gaussmf(x22(n),[0.2,ii211]); 
        kk21=kk21+1;
        end
    end
    ps21(:,n)=p21'/sum(p21);
   
    www21(:,n)=gamma21*((v21(n)/((kb21)^2-(v21(n))^2)))*ps21(:,n)-pro21*w21(:,n);
    ww21=kaka2.*www21/gamma(alpha);
    w21(:,n+1)=w21(:,1)+h*sum(ww21,2);
    
    beta21(n)=-k21*z21(n)-w21(:,n)'*ps21(:,n)+dy2d(n)-q21*lamda21(n);
    
    alpha22(1)=beta21(1);
    alpha2211(n)=(beta21(n)-alpha22(n))/tao12;
    alpha221=kaka2.* alpha2211/gamma(alpha);
    alpha22(n+1)=alpha22(1)+h*sum(alpha221);
    chi2111(n)=-k21*chi21(n)+chi22(n)+(alpha22(n)-beta21(n));
    chi211=kaka2.*chi2111/gamma(alpha);
    chi21(n+1)=chi21(1)+h*sum(chi211);
    x21jian11(n)=x22jian(n)+m21*(y2d(n)-x21jian(n))+w21(:,n)'*ps21(:,n);
    x21jian1=kaka2.*x21jian11/gamma(alpha);
    x21jian(n+1)=x21jian(1)+h*sum(x21jian1);
    
    f21jian(n)=w21(:,n)'*ps21(:,n);
    lamda22(1)=0.001;
    
    z22(n)=x22jian(n)-alpha22(n)-lamda22(n);
    v22(n)=z22(n)-chi22(n);
     kk22=1;   
    for ii22=-1.5:1:1.5
        for ii222=-1.5:1:1.5
            for ii2222=-1.5:1:1.5
                for ii22222=-1.5:1:1.5
                 p22(kk22)=gaussmf(x11(n),[0.2,ii22])*gaussmf(x12(n),[0.5,ii222])*gaussmf(x21(n),[0.2,ii2222])*gaussmf(x22(n),[0.2,ii22222]);
                kk22=kk22+1;
                end
            end
        end
    end
    ps22(:,n)=p22'/sum(p22);   

    www22(:,n)=gamma22*((v22(n)/((kb22)^2-(v22(n))^2)))*ps22(:,n)-pro22*w22(:,n);
    ww22=kaka2.*www22/gamma(alpha);
    w22(:,n+1)=w22(:,1)+h*sum(ww22,2);
    
    phi2(n)=-k22*z22(n)-w22(:,n)'*ps22(:,n)+alpha2211(n)-m22*(y2d(n)-x21jian(n))-q22*lamda22(n)-(((kb22)^2-(v22(n))^2)*z21(n))/((kb21)^2-(v21(n))^2);
    theta2=0.2;iota2=0.2;bariota2=0.1;
    iota2q=0.25;bariota2q=0.2;varsigmal2=1;
   eta2(n)=-(1+theta2)*(phi2(n)*tanh((v22(n)*phi2(n))/(varsigmal2*(kb22^2-(v22(n))^2)))+iota2*tanh((v22(n)*iota2)/(varsigmal2*(kb22^2-(v22(n))^2))));
     eta2q(n)=phi2(n)-iota2q*tanh((v22(n)*iota2q)/(varsigmal2*(kb22^2-(v22(n))^2)));
    count2=(n-1)*h;% 
    if abs(phi2(n))<0.5
    if n>1 &&  abs(phi2(n)-vv2(n-1))<(bariota2+theta2*abs(vv2(n-1)))
       vv2(n)=vv2(n-1);
    else 
        vv2(n)=phi2(n);
        rt2=[rt2;count2];% 
        rtt2=[rtt2;count2-tk2];% 
        tk2=count2;% 
        num2=num2+1;
    end
    else
         if n>1 &&  abs(phi2(n)-vv2(n-1))<bariota2q
       vv2(n)=vv2(n-1);
    else 
        vv2(n)=phi2(n);
        rt2=[rt2;count2];% 
        rtt2=[rtt2;count2-tk2];% 
        tk2=count2;% 
        num2=num2+1;
    end
    end
  u2min=25;u2max=10;
   if vv2(n)>=u2max
      u2(n)=u2max;
    elseif -u2min<vv2(n)&&vv2(n)<u2max
       u2(n)=vv2(n);
   else 
       u2(n)=-u2min;
   end
   
   du2(n)=u2(n)-vv2(n);
   lam222(n)=-q22*lamda22(n)+du2(n);
   lam22=kaka2.*lam222/gamma(alpha);
   lamda22(n+1)=lamda22(1)+h*sum(lam22);
   lam211(n)=lamda22(n)-q21*lamda21(n);
   lam21=kaka2.*lam211/gamma(alpha);
   lamda21(n+1)=lamda21(1)+h*sum(lam21);
    chi2211(n)=-k22*chi22(n)-((kb22^2-(v22(n))^2)/(kb21^2-(v21(n))^2))*chi21(n);
   chi221=kaka2.*chi2211/gamma(alpha);
   chi22(n+1)=chi22(1)+h*sum(chi221);
    x22jian11(n)=u2(n)+m22*(y2d(n)-x21jian(n))+w22(:,n)'*ps22(:,n);
    x22jian1=kaka2.*x22jian11/gamma(alpha);
    x22jian(n+1)=x22jian(1)+h*sum(x22jian1);
    
    
    f22jian(n)=w22(:,n)'*ps22(:,n);
   xxx21(n)=x22(n)+f21(n)+d21(n);
   xx21=kaka2.*xxx21/gamma(alpha);
   x21(n+1)=x21(1)+h*sum(xx21);
   xxx22(n)=u2(n)+f22(n)+d22(n);
   xx22=kaka2.*xxx22/gamma(alpha);
   x22(n+1)=x22(1)+h*sum(xx22);
   Q1(n)=norm(w11(:,n),2);
  Q2(n)=norm(w12(:,n),2);
  Q3(n)=norm(w21(:,n),2);
  Q4(n)=norm(w22(:,n),2);
   
end 
figure(1)
subplot(2,1,1)
plot(t,x11,'LineWidth',1.7)%t(1:n),kbcc1,t(1:n),kbcc11,
xlabel('Time(second)')
legend({'$y_{1,r}$', '$\xi_{1,1}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -1.6 2])
hold on
subplot(2,1,2)
plot(t(1:n),z11,'LineWidth',1.7)%t(1:n),kbcc1,t(1:n),kbcc11,
xlabel('Time(second)')
legend({'$z_{11}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -0.1 0.3])
hold on


figure(2)
subplot(2,1,1)
plot(t,x21,'LineWidth',1.7)%t(1:n),kbcc1,t(1:n),kbcc11,
xlabel('Time(second)')
legend({'$y_{2,r}$', '$\xi_{2,1}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -1.6 2])
hold on
subplot(2,1,2)
plot(t(1:n),z21,'LineWidth',1.7)%t(1:n),kbcc1,t(1:n),kbcc11,
xlabel('Time(second)')
legend({'$z_{21}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -0.1 0.3])
hold on

figure(3)
subplot(2,1,1)
plot(t(1:n),x11jian(1:n),'--','LineWidth',2)
xlabel('Time(second)')
legend({'$\xi_{1,1}$', '$\hat{\xi}_{1,1}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -2 2.5])
hold on
subplot(2,1,2)
plot(t(1:n),x12jian(1:n),'--','LineWidth',2)
xlabel('Time(second)')
legend({'$\xi_{1,2}$', '$\hat{\xi}_{1,2}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -2 2.5])
hold on

figure(4)
subplot(2,1,1)
plot(t(1:n),x21jian(1:n),'--','LineWidth',2)
xlabel('Time(second)')
legend({'$\xi_{2,1}$', '$\hat{\xi}_{2,1}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -2 2.5])
hold on
subplot(2,1,2)
plot(t(1:n),x22jian(1:n),'--','LineWidth',2)
xlabel('Time(second)')
legend({'$\xi_{2,2}$', '$\hat{\xi}_{2,2}$'},'Interpreter','latex')
legend('boxoff')
axis([0 40 -2 2.5])
hold on 
% 

% figure(5)
% subplot(2,1,1)
% plot(t(1:n),u1,t(1:n),phi1,'--','LineWidth',2)
% xlabel('Time(second)')
% legend({'$u_{1}(\bar{v}_{1})$','$\phi_1$'},'Interpreter','latex')
% legend('boxoff')
% axis([0 40 -30 20])
% subplot(2,1,2)
% stem(rt1,rtt1,'LineWidth',1.7)
% xlabel('Time(second)')
% ylabel('Amplitude') 
% 
% 
% 
% figure(6)
% subplot(2,1,1)
% plot(t(1:n),u2,t(1:n),phi2,'--','LineWidth',2)
% xlabel('Time(second)')
% legend({'$u_{2}(\bar{v}_{2})$','$\phi_2$'},'Interpreter','latex')
% legend('boxoff')
% axis([0 40 -30 20])
% subplot(2,1,2)
% stem(rt2,rtt2,'LineWidth',1.7)
% xlabel('Time(second)')
% ylabel('Amplitude') 

figure(1)
subplot(2,1,1)
plot(t(1:n),kbc11,t(1:n),kbc111,'HandleVisibility','off')%
hold on



figure(2)
subplot(2,1,1)
plot(t(1:n),kbc21,t(1:n),kbc211,'HandleVisibility','off')%
hold on

figure(3)
subplot(2,1,1)
plot(t(1:n),kbc11,t(1:n),kbc111,'HandleVisibility','off')%
hold on
subplot(2,1,2)
plot(t(1:n),kbc12,t(1:n),kbc121,'HandleVisibility','off')%
hold on

figure(4)
subplot(2,1,1)
plot(t(1:n),kbc21,t(1:n),kbc211,'HandleVisibility','off')%
hold on
subplot(2,1,2)
plot(t(1:n),kbc22,t(1:n),kbc221,'HandleVisibility','off')%
hold on

